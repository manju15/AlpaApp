﻿using System.Web;
using System.Web.Optimization;

namespace AlpaSankyatharaApp
{
    public class BundleConfig
    {
        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/javascripts").Include(
                        "~/Scripts/jquery.min.js",
                        "~/Scripts/jquery-migrate.min.js",
                        "~/Scripts/bootstrap.bundle.min.js",
                        "~/Scripts/easing.min.js",
                        "~/Scripts/hoverIntent.js",
                        "~/Scripts/superfish.min.js",
                        "~/Scripts/wow.min.js",
                        "~/Scripts/owl.carousel.min.js",
                        "~/Scripts/magnific-popup.min.js",
                        "~/Scripts/sticky.js",
                        "~/Scripts/main.js"));

            bundles.Add(new StyleBundle("~/Content/bootstrap").Include(
                      "~/Content/bootstrap.min.css"));

            bundles.Add(new StyleBundle("~/Content/library").Include(
                      "~/Content/font-awesome.min.css",
                      "~/Content/animate.min.css",
                      "~/Content/ionicons.min.css",
                      "~/Content/owl.carousel.min.css",
                      "~/Content/magnific-popup.css"));

            bundles.Add(new StyleBundle("~/Content/main").Include(
                      "~/Content/style.css",
                      "~/Content/KannadaStyle.css"));
        }
    }
}
